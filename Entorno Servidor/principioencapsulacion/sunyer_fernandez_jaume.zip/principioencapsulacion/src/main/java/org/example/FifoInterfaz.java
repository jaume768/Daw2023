package org.example;

public interface FifoInterfaz {

    void add(Persona persona);

    void del();

    int size();
}
