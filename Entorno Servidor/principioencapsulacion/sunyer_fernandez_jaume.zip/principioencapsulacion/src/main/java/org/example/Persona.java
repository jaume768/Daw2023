package org.example;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
public @Data class Persona {

    private String nombre;


}
