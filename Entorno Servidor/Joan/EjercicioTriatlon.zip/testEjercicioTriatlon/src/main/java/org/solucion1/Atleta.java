package org.solucion1;

public class Atleta {
    private String nom;
    private String cognom;
}
