package org.solucion1;

import lombok.Data;

public class Nadador extends Atleta implements NadadorI {

    private String bañador;

    @Override
    public String getBananor() {
        return this.bañador;
    }

    @Override
    public void setBanador(String banador) {
    this.bañador = banador;
    }
}
