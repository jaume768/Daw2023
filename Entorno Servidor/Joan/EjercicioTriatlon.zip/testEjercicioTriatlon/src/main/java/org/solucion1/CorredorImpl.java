package org.solucion1;

public class CorredorImpl extends Atleta implements Corredor{
    @Override
    public String getSabates() {
        return null;
    }

    @Override
    public void setSabates(String sabates) {

    }
}
