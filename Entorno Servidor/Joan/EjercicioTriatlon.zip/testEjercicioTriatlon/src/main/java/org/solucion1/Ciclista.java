package org.solucion1;

public interface Ciclista {

    String getBici();
    void setBici(String bici);
}
