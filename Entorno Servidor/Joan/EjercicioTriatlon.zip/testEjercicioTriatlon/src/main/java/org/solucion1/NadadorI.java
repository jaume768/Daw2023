package org.solucion1;

public interface NadadorI {

    String getBananor();

    void setBanador(String banador);

}
