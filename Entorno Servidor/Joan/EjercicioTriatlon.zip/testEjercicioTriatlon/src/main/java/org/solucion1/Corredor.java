package org.solucion1;

import lombok.Data;

public interface Corredor  {

    String getSabates();

   void setSabates(String sabates);
}
