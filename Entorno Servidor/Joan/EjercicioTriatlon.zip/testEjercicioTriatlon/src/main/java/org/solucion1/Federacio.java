package org.solucion1;

public interface Federacio {

    void numLLicencia();

}
