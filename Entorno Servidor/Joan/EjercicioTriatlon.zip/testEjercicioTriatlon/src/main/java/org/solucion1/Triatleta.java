package org.solucion1;

public interface Triatleta extends Ciclista, Corredor, NadadorI {


}
